#!/usr/bin/env python3
"""Lightweight checks for Lai Academic Paper projects.

Usage:
    python validate.py path/to/main.tex
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate.py path/to/main.tex", file=sys.stderr)
        return 2

    tex = Path(sys.argv[1]).resolve()
    if not tex.exists():
        print(f"ERROR: file not found: {tex}", file=sys.stderr)
        return 2

    text = tex.read_text(encoding="utf-8")
    base = tex.with_suffix("")
    log = base.with_suffix(".log")
    pdf = base.with_suffix(".pdf")

    warnings: list[str] = []
    errors: list[str] = []

    hardcoded = re.findall(r"(?:Figure|Table|Fig\.|图|表)\s*\??\d+", text)
    if hardcoded:
        warnings.append(
            "Possible hard-coded figure/table numbering found; prefer \\label + \\cref: "
            + ", ".join(sorted(set(hardcoded))[:8])
        )

    for token in ("Figure ?", "Table ?", "图 ?", "表 ?", "TODO", "TBD"):
        if token in text:
            warnings.append(f"Placeholder remains in source: {token}")

    labels = set(re.findall(r"\\label\{([^}]+)\}", text))
    refs: set[str] = set()
    for group in re.findall(r"\\(?:ref|eqref|cref|Cref)\{([^}]+)\}", text):
        refs.update(item.strip() for item in group.split(",") if item.strip())
    missing_labels = sorted(refs - labels)
    if missing_labels:
        errors.append("References without matching labels: " + ", ".join(missing_labels))

    cites = set()
    for group in re.findall(r"\\(?:auto|text|paren)?cite\w*\{([^}]+)\}", text):
        cites.update(k.strip() for k in group.split(",") if k.strip())

    bib_match = re.search(r"\\addbibresource\{([^}]+)\}", text)
    if bib_match:
        bib = tex.parent / bib_match.group(1)
        if not bib.exists():
            errors.append(f"Bibliography file not found: {bib}")
        else:
            bib_text = bib.read_text(encoding="utf-8")
            bib_keys = set(re.findall(r"@\w+\s*\{\s*([^,\s]+)", bib_text))
            missing_cites = sorted(cites - bib_keys)
            if missing_cites:
                errors.append("Citation keys missing from bibliography: " + ", ".join(missing_cites))

    for image in re.findall(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}", text):
        candidate = tex.parent / image
        if candidate.suffix:
            exists = candidate.exists()
        else:
            exists = any((tex.parent / f"{image}{ext}").exists() for ext in (".pdf", ".png", ".jpg", ".jpeg"))
        if not exists:
            errors.append(f"Image not found: {image}")

    if log.exists():
        log_text = log.read_text(encoding="utf-8", errors="ignore")
        for pattern, label in [
            (r"LaTeX Warning: There were undefined references", "Undefined references in log"),
            (r"LaTeX Warning: Citation .* undefined", "Undefined citation in log"),
            (r"Overfull \\hbox", "Overfull horizontal box in log"),
            (r"Overfull \\vbox", "Overfull vertical box in log"),
        ]:
            if re.search(pattern, log_text):
                warnings.append(label)
    else:
        warnings.append("No .log file found; compile before final validation")

    if pdf.exists() and shutil.which("pdftotext"):
        proc = subprocess.run(
            ["pdftotext", str(pdf), "-"],
            check=False,
            capture_output=True,
            text=True,
        )
        extracted = proc.stdout
        if "??" in extracted:
            warnings.append("Compiled PDF may contain unresolved cross-references (??)")
        if not extracted.strip():
            warnings.append("No extractable text found in PDF")
    elif not pdf.exists():
        warnings.append("No compiled PDF found")

    print(f"Validated: {tex}")
    for item in warnings:
        print(f"WARNING: {item}")
    for item in errors:
        print(f"ERROR: {item}")

    if errors:
        print(f"Result: FAIL ({len(errors)} error(s), {len(warnings)} warning(s))")
        return 1
    print(f"Result: PASS ({len(warnings)} warning(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
