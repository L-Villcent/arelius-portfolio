$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
xelatex -interaction=nonstopmode -halt-on-error main.tex
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
biber main
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
xelatex -interaction=nonstopmode -halt-on-error main.tex
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
xelatex -interaction=nonstopmode -halt-on-error main.tex
exit $LASTEXITCODE
