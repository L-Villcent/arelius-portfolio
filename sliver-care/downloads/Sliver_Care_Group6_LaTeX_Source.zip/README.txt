SLIVER CARE / GROUP6 / ACADEMIC REPORT SOURCE

Mode: Faithful Typesetting using lai-academic-paper.
The approved decision, roster, eight body sections, pricing, outcomes, evidence
and limitations are retained. Formulas restate the supplied arithmetic.

Course adaptation: page one leads with the real project decision and the full
team roster. A separate journal abstract is not added because the course asks
for a decision-led report. The eight-section structure and appendix are kept.

Build requirements: a TeX distribution with XeLaTeX, Biber and the packages
declared in main.tex. Standard Latin Modern fonts are resolved by TeX; font
files are not included in this source package.

Windows: run compile.ps1 from a PowerShell session with TeX on PATH.
Linux/macOS: bash compile.sh main.tex
Overleaf: upload the source ZIP, choose XeLaTeX and compile main.tex with Biber.

main.tex is the editable report. references.bib contains the 24 supplied local
sources; it does not add external research or invented bibliographic metadata.
Evidence paths retain their original package locations. Actual outreach uses
representative excerpts; earlier simulated records are archived separately. Product test files are original recordings.

The Word file in the main offline product remains a content editing copy with
its earlier layout. The academic PDF is compiled from this LaTeX source.
