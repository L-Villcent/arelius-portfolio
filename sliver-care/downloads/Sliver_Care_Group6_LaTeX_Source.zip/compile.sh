#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 path/to/main.tex" >&2
  exit 2
fi

TEX_PATH=$(python3 - <<'PY' "$1"
import os, sys
print(os.path.abspath(sys.argv[1]))
PY
)
WORKDIR=$(dirname "$TEX_PATH")
TEXFILE=$(basename "$TEX_PATH")
BASENAME=${TEXFILE%.tex}

cd "$WORKDIR"

xelatex -interaction=nonstopmode -halt-on-error "$TEXFILE"
if grep -q "\\addbibresource" "$TEXFILE"; then
  biber "$BASENAME"
fi
xelatex -interaction=nonstopmode -halt-on-error "$TEXFILE"
xelatex -interaction=nonstopmode -halt-on-error "$TEXFILE"

printf 'Compiled: %s/%s.pdf\n' "$WORKDIR" "$BASENAME"
